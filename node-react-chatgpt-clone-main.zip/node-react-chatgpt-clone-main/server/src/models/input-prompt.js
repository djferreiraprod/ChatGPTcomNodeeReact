class InputPrompt {
	constructor({prompt}){
		this.prompt = prompt
	}
}

module.exports = InputPrompt
